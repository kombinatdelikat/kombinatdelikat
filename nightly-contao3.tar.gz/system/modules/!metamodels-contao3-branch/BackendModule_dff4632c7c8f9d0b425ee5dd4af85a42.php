<?php
/**
 * Auto generated summary class for nightly build.
 *
 * See https://github.com/discordier/nightly-builder to learn how it works.
 */
class BackendModule_dff4632c7c8f9d0b425ee5dd4af85a42 extends \BackendModule
{
	/**
	 * Display the overview.
	 */
	public function generate()
	{
		$GLOBALS['TL_CSS'][] = 'system/modules/!metamodels-contao3-branch/html/style.css';
		$baseUrl = \Environment::getInstance()->base . '/system/modules/!metamodels-contao3-branch/html/github-btn.html';
		return '<div class="tl_message"><table class="table table-striped nightlyinfo">
	<colgroup>
		<col width="200" />
		<col width="150" />
		<col width="90" />
		<col width="90" />
		<col width="160" />
	</colgroup>
	<thead>
		<tr>
			<th class="name">Package</th>
			<th class="version">Version</th>
			<th class="time">Time</th>
			<th class="license">License</th>
			<th class="buttons">Github</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td class="name"><a href="https://github.com/bit3/contao-meta-palettes" target="_blank">bit3/contao-meta-palettes</a></td>
			<td class="version">1.5.4</td>
			<td class="time">2013-12-11 07:01:03</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=bit3&repo=contao-meta-palettes&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=bit3&repo=contao-meta-palettes&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/contao-community-alliance/backports-initialize-system" target="_blank">contao-community-alliance/backports-initialize-system</a></td>
			<td class="version">dev-develop&nbsp;@&nbsp;0d0515</td>
			<td class="time">2014-06-05 11:58:46</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=backports-initialize-system&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=backports-initialize-system&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/contao-community-alliance/composer-plugin" target="_blank">contao-community-alliance/composer-plugin</a></td>
			<td class="version">dev-master&nbsp;@&nbsp;e0859b</td>
			<td class="time">2014-06-18 12:11:25</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=composer-plugin&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=composer-plugin&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/contao-community-alliance/dependency-container" target="_blank">contao-community-alliance/dependency-container</a></td>
			<td class="version">dev-develop&nbsp;@&nbsp;7fa301</td>
			<td class="time">2014-06-05 08:30:58</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=dependency-container&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=dependency-container&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/contao-community-alliance/event-dispatcher" target="_blank">contao-community-alliance/event-dispatcher</a></td>
			<td class="version">1.1.1</td>
			<td class="time">2014-05-27 02:58:55</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=event-dispatcher&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=contao-community-alliance&repo=event-dispatcher&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/discordier/justtextwidgets" target="_blank">discordier/justtextwidgets</a></td>
			<td class="version">dev-master&nbsp;@&nbsp;687e04</td>
			<td class="time">2014-02-05 22:52:54</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=discordier&repo=justtextwidgets&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=discordier&repo=justtextwidgets&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/menatwork/MultiColumnWizard" target="_blank">menatwork/contao-multicolumnwizard</a></td>
			<td class="version">dev-dev&nbsp;@&nbsp;ea15b3</td>
			<td class="time">2014-06-17 18:56:58</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=menatwork&repo=MultiColumnWizard&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=menatwork&repo=MultiColumnWizard&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_alias" target="_blank">metamodels/attribute_alias</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;38a75b</td>
			<td class="time">2014-04-18 21:36:49</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_alias&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_alias&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_checkbox" target="_blank">metamodels/attribute_checkbox</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;68db82</td>
			<td class="time">2014-05-08 03:35:00</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_checkbox&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_checkbox&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_combinedvalues" target="_blank">metamodels/attribute_combinedvalues</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;9da6d4</td>
			<td class="time">2014-01-20 19:40:56</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_combinedvalues&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_combinedvalues&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_country" target="_blank">metamodels/attribute_country</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;b04f36</td>
			<td class="time">2014-04-25 03:24:55</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_country&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_country&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_decimal" target="_blank">metamodels/attribute_decimal</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;f9a720</td>
			<td class="time">2014-04-25 04:07:09</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_decimal&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_decimal&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_file" target="_blank">metamodels/attribute_file</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;5dc946</td>
			<td class="time">2014-05-29 00:33:10</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_file&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_file&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_langcode" target="_blank">metamodels/attribute_langcode</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;950a72</td>
			<td class="time">2014-04-25 05:10:44</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_langcode&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_langcode&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_longtext" target="_blank">metamodels/attribute_longtext</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;2a313b</td>
			<td class="time">2013-09-03 01:18:18</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_longtext&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_longtext&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_numeric" target="_blank">metamodels/attribute_numeric</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;c305d4</td>
			<td class="time">2013-09-03 01:42:12</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_numeric&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_numeric&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_select" target="_blank">metamodels/attribute_select</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;1a15c2</td>
			<td class="time">2014-04-25 07:23:06</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_select&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_select&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_tabletext" target="_blank">metamodels/attribute_tabletext</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;5c1e19</td>
			<td class="time">2014-03-24 10:59:36</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_tabletext&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_tabletext&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_tags" target="_blank">metamodels/attribute_tags</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;450ed6</td>
			<td class="time">2014-05-08 03:48:22</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_tags&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_tags&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_text" target="_blank">metamodels/attribute_text</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;132d01</td>
			<td class="time">2014-04-25 10:03:12</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_text&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_text&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_timestamp" target="_blank">metamodels/attribute_timestamp</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;9918c3</td>
			<td class="time">2014-06-12 10:47:58</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_timestamp&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_timestamp&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedalias" target="_blank">metamodels/attribute_translatedalias</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;0127b7</td>
			<td class="time">2014-01-20 19:45:53</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedalias&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedalias&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedcheckbox" target="_blank">metamodels/attribute_translatedcheckbox</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;14486e</td>
			<td class="time">2014-04-30 18:28:37</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedcheckbox&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedcheckbox&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedcombinedvalues" target="_blank">metamodels/attribute_translatedcombinedvalues</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;43d5cd</td>
			<td class="time">2014-02-17 14:44:12</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedcombinedvalues&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedcombinedvalues&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedfile" target="_blank">metamodels/attribute_translatedfile</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;8b3aee</td>
			<td class="time">2014-04-24 13:12:27</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedfile&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedfile&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedlongtext" target="_blank">metamodels/attribute_translatedlongtext</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;635f7c</td>
			<td class="time">2014-01-20 19:48:02</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedlongtext&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedlongtext&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedselect" target="_blank">metamodels/attribute_translatedselect</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;5a721d</td>
			<td class="time">2014-05-20 01:34:16</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedselect&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedselect&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedtabletext" target="_blank">metamodels/attribute_translatedtabletext</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;d7df0b</td>
			<td class="time">2014-02-11 17:27:14</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedtabletext&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedtabletext&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedtags" target="_blank">metamodels/attribute_translatedtags</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;f59319</td>
			<td class="time">2014-03-13 10:03:48</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedtags&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedtags&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_translatedtext" target="_blank">metamodels/attribute_translatedtext</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;d831f8</td>
			<td class="time">2014-01-20 16:49:03</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedtext&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_translatedtext&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/attribute_url" target="_blank">metamodels/attribute_url</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;da4a15</td>
			<td class="time">2014-05-08 03:51:13</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_url&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=attribute_url&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/core" target="_blank">metamodels/core</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;ccc32f</td>
			<td class="time">2014-05-08 13:19:32</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=core&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=core&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/DC_General" target="_blank">metamodels/dc_general</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;6487ca</td>
			<td class="time">2014-06-02 20:16:15</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=DC_General&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=DC_General&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/filter_checkbox" target="_blank">metamodels/filter_checkbox</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;e4c167</td>
			<td class="time">2014-04-25 13:10:05</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_checkbox&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_checkbox&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/filter_fromto" target="_blank">metamodels/filter_fromto</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;c4e96f</td>
			<td class="time">2014-04-25 15:51:48</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_fromto&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_fromto&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/filter_range" target="_blank">metamodels/filter_range</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;2d5d9e</td>
			<td class="time">2014-01-20 19:49:23</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_range&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_range&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/filter_select" target="_blank">metamodels/filter_select</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;6ce893</td>
			<td class="time">2014-04-25 17:15:51</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_select&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_select&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/filter_tags" target="_blank">metamodels/filter_tags</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;adfb7a</td>
			<td class="time">2014-05-08 03:50:10</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_tags&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_tags&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/MetaModels/filter_text" target="_blank">metamodels/filter_text</a></td>
			<td class="version">dev-contao3&nbsp;@&nbsp;18557e</td>
			<td class="time">2014-04-28 18:58:56</td>
			<td class="license"><a href="http://spdx.org/licenses/LGPL-3.0+" target="_blank">LGPL-3.0+</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_text&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=MetaModels&repo=filter_text&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/fabpot/Pimple" target="_blank">pimple/pimple</a></td>
			<td class="version">1.1.x-dev&nbsp;@&nbsp;bc2fc1</td>
			<td class="time">2014-04-20 07:24:09</td>
			<td class="license"><a href="http://spdx.org/licenses/MIT" target="_blank">MIT</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=fabpot&repo=Pimple&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=fabpot&repo=Pimple&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
		<tr>
			<td class="name"><a href="https://github.com/symfony/EventDispatcher" target="_blank">symfony/event-dispatcher</a></td>
			<td class="version">2.3.x-dev&nbsp;@&nbsp;cb7cd3</td>
			<td class="time">2014-04-16 10:30:19</td>
			<td class="license"><a href="http://spdx.org/licenses/MIT" target="_blank">MIT</a></td>
			<td class="buttons">
				<iframe src="' . $baseUrl . '?user=symfony&repo=EventDispatcher&type=watch&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="110" height="20"></iframe>
				<iframe src="' . $baseUrl . '?user=symfony&repo=EventDispatcher&type=fork&count=true" allowtransparency="true" frameborder="0" scrolling="0" width="95" height="20"></iframe>
</td>
		</tr>
	</tbody>
</table></div>
';
	}

	// No-Op to make the class non abstract.
	protected function compile(){}
}