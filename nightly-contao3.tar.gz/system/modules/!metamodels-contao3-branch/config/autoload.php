<?php

/**
 * THIS BLOCK HAS BEEN ADDED BY THE NIGHTLY PACKAGE BUILDER.
 * DO NOT REMOVE!
 */

require_once(TL_ROOT . '/system/modules/!metamodels-contao3-branch/config/vendor_autoload.php');

/**
 * END OF NIGHTLY PACKAGE BUILDER ADDED BLOCK.
 */
