<?php
/**
 * PHP version 5
 * @package    generalDriver
 * @author     Christian Schiffler <c.schiffler@cyberspectrum.de>
 * @author     Stefan Heimes <stefan_heimes@hotmail.com>
 * @author     Tristan Lins <tristan.lins@bit3.de>
 * @copyright  The MetaModels team.
 * @license    LGPL.
 * @filesource
 */

trigger_error('Usage of deprecated '. __FILE__, E_USER_DEPRECATED);
/**
 * @deprecated
 */
class GeneralDataModelDefault extends DcGeneral\Data\DefaultModel
{
}
