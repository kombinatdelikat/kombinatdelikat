<?php

namespace DcGeneral\View;

interface ViewTemplateInterface
{
}
