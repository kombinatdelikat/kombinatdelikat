<?php

namespace DcGeneral\View;

class ContaoBackendViewTemplate extends \BackendTemplate implements ViewTemplateInterface
{
}
