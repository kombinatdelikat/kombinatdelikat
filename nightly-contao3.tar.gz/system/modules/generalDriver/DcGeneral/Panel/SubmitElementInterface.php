<?php

namespace DcGeneral\Panel;

use DcGeneral\Panel\PanelElementInterface;

interface SubmitElementInterface extends PanelElementInterface
{
}
