<?php

/**
 * PHP version 5
 * @package	   generalDriver
 * @author     Christian Schiffler <c.schiffler@cyberspectrum.de>
 * @copyright  The MetaModels team.
 * @license    LGPL.
 * @filesource
 */

// Contao 2.X compatibility
require_once TL_ROOT . '/system/modules/generalDriver/DC_General.php';